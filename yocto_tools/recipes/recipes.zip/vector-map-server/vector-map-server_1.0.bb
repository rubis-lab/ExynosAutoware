inherit ros_distro_melodic
inherit ros_superflore_generated

DESCRIPTION = "The vector_map_server package"
AUTHOR = "Hayeon Park <kite9240@gmail.com>"
HOMEPAGE = "https://none"
SECTION = "devel"

LICENSE = "Apache-2.0"
LIC_FILES_CHKSUM = "file://package.xml;beginline=7;endline=7;md5=fc216ef9336537897fbeafa564601763"

ROS_CN = "vector_map_server"
ROS_BPN = "vector_map_server"

ROS_BUILD_DEPENDS = " \
	message-generation \
	autoware-msgs \
	geometry-msgs \
	roslint \
	vector-map \
	vector-map-msgs \
	visualization-msgs \
	message-runtime \
"

ROS_BUILDTOOL_DEPENDS = " \
	catkin-native \
"

ROS_EXPORT_DEPENDS = " \
	message-generation \
	autoware-msgs \
	geometry-msgs \
	roslint \
	vector-map \
	vector-map-msgs \
	visualization-msgs \
	message-runtime \
"

ROS_BUILDTOOL_EXPORT_DEPENDS = ""

ROS_EXEC_DEPENDS = " \
	message-generation \
	autoware-msgs \
	geometry-msgs \
	roslint \
	vector-map \
	vector-map-msgs \
	visualization-msgs \
	message-runtime \
"

ROS_TEST_DEPENDS = ""

DEPENDS = "${ROS_BUILD_DEPENDS} ${ROS_BUILDTOOL_DEPENDS}"
DEPENDS += "${ROS_EXPORT_DEPENDS} ${ROS_BUILDTOOL_EXPORT_DEPENDS}"

RDEPENDS_${PN} += "${ROS_EXEC_DEPENDS}"

ROS_BRANCH = "branch=vector_map_server"
SRC_URI = "git://github.com/rubis-lab/ExynosAutoware;${ROS_BRANCH};protocol=https"
SRCREV = "fa27bb0ab3854c940dce512dadf0db13a95c8dab"
S = "${WORKDIR}/git"

ROS_BUILD_TYPE = "cmake"

inherit ros_catkin
BBCLASSEXTEND_append = "native nativesdk"

FILES_${PN} += " \
	${ros_libdir}/*/* \
"

FILES_${PN}-dev += " \
	${ros_libdir}/*/* \
"